
<!DOCTYPE html>
<html lang="en">
    <head>
            <style>
              body {
                        background-color: #93B874;
                    }
                    h1 {
                        background-color: #00b33c;
                    }
                    p {
                        background-color: #FFFFFF);
                    }
            </style>
    </head>

<body>

<ul class="nav navbar-nav" >
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                </ul>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                    <li>
                        <a href="peminjamanuser.php">Data Peminjaman</a>
                    </li>
            </ul>

        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
            
        <br>
        <center><h1 class="page-header">Halaman Sanksi</h1></center>
    
     <h1>Sanksi Keterlambatan Pengembalian</h1>
     <p><font size="3">Pada setiap keterlambatan pengembalian maka siswa akan dikenakan denda 
      sebesar Rp. 1.000 perhari.<br><br>
     
     </font></p>
    <br>
      <h1>Sanksi Kehilangan Barang</h1>
     <p>Jika barang atau alat yang dipinjam hilang maka siswa wajib mengganti dengan jenis barang yang sama, atau juga bisa dengan
      membayar denda dengan seharga barang atau hilang tersebut.</p>
    <br>
    <center><a href="index.php"><input type="button" value="Kembali ke Home"></a></center>

</body>
</html>