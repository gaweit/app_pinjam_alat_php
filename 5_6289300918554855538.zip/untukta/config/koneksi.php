<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "pemin_alat";
$mysqli = new mysqli($host,$username,$password, $db) or die('koneksi error');

?>